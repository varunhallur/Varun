# bubble-sort-simulation-
bubble sort simulation using opengl / c++ implementation

To run the file 
1. open terminal and run below command

g++ gl.cpp -o gl -lGL -lGLU -lglut

after above command object file will be created 
then run

./a.out
