<?php
require_once '../header.php';
 ?>

<div class="">
  <h1>Premium Payment Record</h1>
  <button name=""><a href="AddPaymentRecord.php"> Add Payment Record </a></button>
  <button name=""><a href="ShowRecordBook.php"> Show Record Book </a></button>
</div>

<?php
require_once '../footer.php';
 ?>
