<?php
require_once 'header.php';
 ?>
 <h1>Agent Menu</h1>
<div class="">
  <ol>
    <li>
      <a href="ManagePolicy/ManagePolicy.php"> Manage Policy </a> </li><br>
    <li>
      <a href="PolicyOptions/PlanPresentation.php"> Plan Presentaion </a> </li><br>
      <li>
      <a href="PolicyOptions/SearchPolicyDetails.php"> Search Policy Details </a> </li><br>
      <li>
      <a href="PolicyOptions/CommissionReports.php"> Commission Reports </a> </li><br>
      <li>
      <a href="PolicyOptions/BusinessReport.php"> Business Reports </a></li><br>
      <li>
      <a href="PremiumPaymentRecord/PremiumPaymentRecord.php"> Premium Payment Record </a> </li>
  </ol>

</div>

<?php
require_once 'footer.php';
 ?>
