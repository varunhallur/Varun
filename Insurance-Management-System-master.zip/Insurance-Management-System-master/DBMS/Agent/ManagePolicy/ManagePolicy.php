<?php
require_once '../header.php';
 ?>

<div class="">
  <h1>Manage Policy</h1>
  <button name=""><a href="AddNewPolicy.php"> Add New Policy </a></button>
  <button name=""><a href="UpdatePolicy.php"> Update Policy </a></button>
  <button name=""><a href="DeletePolicy.php"> Delete Policy </a></button>
</div>

<?php
require_once '../footer.php';
 ?>
