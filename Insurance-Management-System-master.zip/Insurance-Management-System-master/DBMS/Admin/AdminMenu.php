<?php
require_once 'header.php';
 ?>

<div class="">
  <h1>Admin Menu</h1>
  <button name=""><a href="Admin-Register.php"> Add New Admin </a></button>
  <button name="" style="margin-left: 46px;"><a href="../Agent/Agent-Register.php"> Add New Agent </a></button><br><br>
  <button name=""><a href="View/ViewAgentList.php"> View Agent List </a></button>
  <button name="" style="margin-left: 50px;"><a href="View/ViewPolicy.php"> View Policy Record </a></button><br><br>
  <button name="" style="margin: 10px 0 0 90px;"><a href="Plan/PlanDetails.php"> Modify Plan </a></button>
</div>

 <?php
 require_once 'footer.php';
  ?>
