<?php
require_once '../header.php';
 ?>

<div class="">
  <h1>Modify Plan</h1>
  <button name=""><a href="AddNewPlan.php"> Add New Plan </a></button>
  <button name=""><a href="../View/ViewPlan.php"> View/Edit Plan </a></button>
</div>


 <?php
 require_once '../footer.php';
  ?>
