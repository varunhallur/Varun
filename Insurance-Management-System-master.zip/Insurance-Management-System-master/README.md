# Insurance-Management-System
This is a web based Insurance Management System made in PHP.

Please read Report for more details on this project. Also please read 'How to run' for instrunctions to run it.
